﻿using CalendarioGerarOrg.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CalendarioGerarOrg.ViewModels
{
    public class cidadeAno
    {
        public List<cidade> cidades { get; set; }
        //public int ano { get; set; }
        public List<int> anos { get; set; }

    }
}
